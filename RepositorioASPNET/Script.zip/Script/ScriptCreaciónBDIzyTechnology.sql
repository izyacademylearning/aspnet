-- Creaci�n de la base de datos
IF NOT EXISTS (SELECT 1 FROM sys.databases WHERE name = 'IzyTechnology')
BEGIN
    CREATE DATABASE IzyTechnology;
END
GO
 
USE IzyTechnology;
GO
 
-- Creaci�n de la tabla de Categor�as
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Categorias')
BEGIN
    CREATE TABLE Categorias (
        CategoriaID INT PRIMARY KEY,
        NombreCategoria NVARCHAR(50)
    );
 
    -- Inserci�n de datos en la tabla de Categor�as
    INSERT INTO Categorias (CategoriaID, NombreCategoria)
    VALUES
    (1, 'Computadores'),
    (2, 'Accesorios'),
    (3, 'Celulares');
END
GO
 
-- Creaci�n de la tabla de Productos
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Productos')
BEGIN
    CREATE TABLE Productos (
        ProductoID INT PRIMARY KEY,
        Nombre NVARCHAR(100),
        Precio DECIMAL(10, 2),
        Stock INT,
        CategoriaID INT FOREIGN KEY REFERENCES Categorias(CategoriaID)
    );
 
    -- Inserci�n de datos en la tabla de Productos con precios en pesos colombianos
    INSERT INTO Productos (ProductoID, Nombre, Precio, Stock, CategoriaID)
    VALUES
    (1, 'Laptop Ultrabook', 4938202.00, 20, 1),
    (2, 'Mouse Inal�mbrico', 113923.62, 50, 2),
    (3, 'Smartphone Android', 2659960.20, 30, 3),
    (4, 'PC Gamer', 6459921.62, 15, 1),
    (5, 'Teclado Mec�nico', 341922.38, 40, 2),
    (6, 'iPhone 13', 3799957.62, 25, 3),
    (7, 'Monitor Curvo', 1519959.62, 20, 1),
    (8, 'Auriculares Bluetooth', 227954.62, 50, 2),
    (9, 'Samsung Galaxy Tab', 1899955.62, 10, 1),
    (10, 'Cargador Inal�mbrico', 75998.12, 100, 2);
END
GO
 
-- Creaci�n de la tabla de Clientes
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Clientes')
BEGIN
    CREATE TABLE Clientes (
        ClienteID INT PRIMARY KEY,
        Nombre NVARCHAR(100),
        Correo NVARCHAR(50),
        Telefono NVARCHAR(15)
    );
 
    -- Inserci�n de datos en la tabla de Clientes
    INSERT INTO Clientes (ClienteID, Nombre, Correo, Telefono)
    VALUES
    (1, 'Juan P�rez', 'juan.perez@example.com', '+573123456789'),
    (2, 'Ana G�mez', 'ana.gomez@example.com', '+573234567890'),
    (3, 'Carlos Rodr�guez', 'carlos.rodriguez@example.com', '+573345678901'),
    (4, 'Laura Vargas', 'laura.vargas@example.com', '+573456789012'),
    (5, 'Miguel L�pez', 'miguel.lopez@example.com', '+573567890123');
END
GO
 
-- Creaci�n de la tabla de Facturas
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Facturas')
BEGIN
    CREATE TABLE Facturas (
        FacturaID INT PRIMARY KEY,
        ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
        Fecha DATE,
        Total DECIMAL(10, 2)
    );
 
    -- Inserci�n de datos en la tabla Facturas
    INSERT INTO Facturas (FacturaID, ClienteID, Fecha, Total)
    VALUES
    (1, 1, '2023-01-15', 500000.00),
    (2, 3, '2023-02-20', 750000.00),
    (3, 2, '2023-03-10', 1200000.00),
    (4, 4, '2023-04-05', 900000.00),
    (5, 5, '2023-05-12', 600000.00);
END
GO
 
-- Creaci�n de la tabla de DetalleFactura
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'DetalleFactura')
BEGIN
    CREATE TABLE DetalleFactura (
        DetalleID INT PRIMARY KEY,
        FacturaID INT FOREIGN KEY REFERENCES Facturas(FacturaID),
        ProductoID INT FOREIGN KEY REFERENCES Productos(ProductoID),
        Cantidad INT,
        PrecioUnitario DECIMAL(10, 2),
        Subtotal DECIMAL(10, 2)
    );
 
    -- Inserci�n de datos en la tabla DetalleFactura
    INSERT INTO DetalleFactura (DetalleID, FacturaID, ProductoID, Cantidad, PrecioUnitario, Subtotal)
    VALUES
    (1, 1, 1, 2, 250000.00, 500000.00),
    (2, 2, 4, 1, 750000.00, 750000.00),
    (3, 3, 6, 3, 400000.00, 1200000.00),
    (4, 4, 3, 2, 450000.00, 900000.00),
    (5, 5, 9, 1, 600000.00, 600000.00);
END
GO
-- Creaci�n de la tabla Pedidos
IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Pedidos')
BEGIN
    CREATE TABLE Pedidos (
        PedidoID INT PRIMARY KEY,
        ClienteID INT FOREIGN KEY REFERENCES Clientes(ClienteID),
        FechaPedido DATE,
        TotalPedido DECIMAL(10, 2)
    );
 
    -- Inserci�n de datos en la tabla Pedidos
    INSERT INTO Pedidos (PedidoID, ClienteID, FechaPedido, TotalPedido)
    VALUES
    (1, 1, '2023-06-01', 800000.00),
    (2, 3, '2023-06-02', 1200000.00),
    (3, 2, '2023-06-03', 500000.00),
    (4, 4, '2023-06-04', 900000.00),
    (5, 5, '2023-06-05', 600000.00);
END
GO